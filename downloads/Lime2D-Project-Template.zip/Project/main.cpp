#include <iostream>
#include "lime2d.h"

int main() {
    sf::RenderWindow window(sf::VideoMode(800, 600), "A Note For Lime", sf::Style::Titlebar | sf::Style::Close);
    l2d::Editor editor(false, &window);
    sf::Clock timer;

    window.setVerticalSyncEnabled(true);

    while (window.isOpen()) {
        sf::Event event;
        while (window.pollEvent(event)) {
            editor.processEvent(event);
            if (event.type == sf::Event::Closed || sf::Keyboard::isKeyPressed(sf::Keyboard::Escape)) {
                window.close();
            }
            else if (event.type == sf::Event::TextEntered && event.text.unicode == '=') {
                editor.toggle();
            }
        }
        editor.update(timer.restart());
        window.clear();
        editor.render();
        window.display();
    }
    editor.exit();
    return 0;
}